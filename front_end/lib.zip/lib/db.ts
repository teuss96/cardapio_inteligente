// Sistema de armazenamento de dados em memória
export interface Produto {
  id: number
  nome: string
  preco: number
  categoria: string
}

export interface Categoria {
  id: number
  nome: string
}

export interface Usuario {
  id: number
  nome: string
  email: string
  senha: string
  tipo: "cliente" | "funcionario"
}

export interface Ingrediente {
  id: number
  nome: string
  unidade: string
  quantidade: number
}

export interface ItemPedido {
  produtoId: number
  quantidade: number
  preco: number
}

export interface Pedido {
  id: number
  clienteId: number
  items: ItemPedido[]
  total: number
  status: "pendente" | "preparando" | "pronto" | "entregue"
  dataCriacao: string
}

// Dados iniciais
const categorias: Categoria[] = [
  { id: 1, nome: "Entradas" },
  { id: 2, nome: "Pratos Principais" },
  { id: 3, nome: "Sobremesas" },
  { id: 4, nome: "Bebidas" },
]

const produtos: Produto[] = [
  { id: 1, nome: "Bruschetta", preco: 18.9, categoria: "Entradas" },
  { id: 2, nome: "Carpaccio", preco: 32.9, categoria: "Entradas" },
  { id: 3, nome: "Filé Mignon", preco: 68.9, categoria: "Pratos Principais" },
  { id: 4, nome: "Salmão Grelhado", preco: 72.9, categoria: "Pratos Principais" },
  { id: 5, nome: "Tiramisu", preco: 22.9, categoria: "Sobremesas" },
  { id: 6, nome: "Petit Gateau", preco: 24.9, categoria: "Sobremesas" },
  { id: 7, nome: "Suco Natural", preco: 12.9, categoria: "Bebidas" },
  { id: 8, nome: "Vinho Tinto", preco: 89.9, categoria: "Bebidas" },
]

const usuarios: Usuario[] = [
  { id: 1, nome: "Admin", email: "admin@restaurante.com", senha: "admin123", tipo: "funcionario" },
  { id: 2, nome: "Cliente Teste", email: "cliente@email.com", senha: "cliente123", tipo: "cliente" },
]

const ingredientes: Ingrediente[] = [
  { id: 1, nome: "Tomate", unidade: "kg", quantidade: 50 },
  { id: 2, nome: "Alface", unidade: "unidade", quantidade: 30 },
  { id: 3, nome: "Carne Bovina", unidade: "kg", quantidade: 25 },
  { id: 4, nome: "Salmão", unidade: "kg", quantidade: 15 },
  { id: 5, nome: "Farinha de Trigo", unidade: "kg", quantidade: 40 },
]

const pedidos: Pedido[] = []

let nextProdutoId = 9
let nextCategoriaId = 5
let nextUsuarioId = 3
let nextIngredienteId = 6
let nextPedidoId = 1

// Funções para categorias
export function getCategorias(): Categoria[] {
  return [...categorias]
}

export function addCategoria(nome: string): Categoria {
  const novaCategoria = { id: nextCategoriaId++, nome }
  categorias.push(novaCategoria)
  return novaCategoria
}

export function updateCategoria(id: number, nome: string): Categoria | null {
  const index = categorias.findIndex((c) => c.id === id)
  if (index === -1) return null
  categorias[index].nome = nome
  return categorias[index]
}

export function deleteCategoria(id: number): boolean {
  const index = categorias.findIndex((c) => c.id === id)
  if (index === -1) return false
  categorias.splice(index, 1)
  return true
}

// Funções para produtos
export function getProdutos(): Produto[] {
  return [...produtos]
}

export function getProdutoById(id: number): Produto | undefined {
  return produtos.find((p) => p.id === id)
}

export function addProduto(nome: string, preco: number, categoria: string): Produto {
  const novoProduto = { id: nextProdutoId++, nome, preco, categoria }
  produtos.push(novoProduto)
  return novoProduto
}

export function updateProduto(id: number, nome: string, preco: number, categoria: string): Produto | null {
  const index = produtos.findIndex((p) => p.id === id)
  if (index === -1) return null
  produtos[index] = { id, nome, preco, categoria }
  return produtos[index]
}

export function deleteProduto(id: number): boolean {
  const index = produtos.findIndex((p) => p.id === id)
  if (index === -1) return false
  produtos.splice(index, 1)
  return true
}

export function getUsuarios(): Usuario[] {
  return usuarios.map((u) => ({ ...u, senha: "" })) // Não retorna senhas
}

export function getUsuarioByEmail(email: string): Usuario | undefined {
  return usuarios.find((u) => u.email === email)
}

export function addUsuario(nome: string, email: string, senha: string, tipo: "cliente" | "funcionario"): Usuario {
  const novoUsuario = { id: nextUsuarioId++, nome, email, senha, tipo }
  usuarios.push(novoUsuario)
  return { ...novoUsuario, senha: "" }
}

export function autenticarUsuario(email: string, senha: string): Usuario | null {
  const usuario = usuarios.find((u) => u.email === email && u.senha === senha)
  if (!usuario) return null
  return { ...usuario, senha: "" }
}

export function getIngredientes(): Ingrediente[] {
  return [...ingredientes]
}

export function addIngrediente(nome: string, unidade: string, quantidade: number): Ingrediente {
  const novoIngrediente = { id: nextIngredienteId++, nome, unidade, quantidade }
  ingredientes.push(novoIngrediente)
  return novoIngrediente
}

export function updateIngrediente(id: number, nome: string, unidade: string, quantidade: number): Ingrediente | null {
  const index = ingredientes.findIndex((i) => i.id === id)
  if (index === -1) return null
  ingredientes[index] = { id, nome, unidade, quantidade }
  return ingredientes[index]
}

export function deleteIngrediente(id: number): boolean {
  const index = ingredientes.findIndex((i) => i.id === id)
  if (index === -1) return false
  ingredientes.splice(index, 1)
  return true
}

export function getPedidos(): Pedido[] {
  return [...pedidos]
}

export function getPedidosByCliente(clienteId: number): Pedido[] {
  return pedidos.filter((p) => p.clienteId === clienteId)
}

export function addPedido(clienteId: number, items: ItemPedido[]): Pedido {
  const total = items.reduce((sum, item) => sum + item.preco * item.quantidade, 0)
  const novoPedido: Pedido = {
    id: nextPedidoId++,
    clienteId,
    items,
    total,
    status: "pendente",
    dataCriacao: new Date().toISOString(),
  }
  pedidos.push(novoPedido)
  return novoPedido
}

export function updatePedidoStatus(id: number, status: Pedido["status"]): Pedido | null {
  const pedido = pedidos.find((p) => p.id === id)
  if (!pedido) return null
  pedido.status = status
  return pedido
}
