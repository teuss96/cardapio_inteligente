import { NextResponse } from "next/server"
import { getProdutos, addProduto } from "@/lib/db"

export async function GET() {
  try {
    const produtos = getProdutos()
    return NextResponse.json(produtos)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao buscar produtos" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { nome, preco, categoria } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome do produto é obrigatório" }, { status: 400 })
    }

    if (!preco || preco <= 0) {
      return NextResponse.json({ erro: "Preço deve ser maior que zero" }, { status: 400 })
    }

    if (!categoria || categoria.trim() === "") {
      return NextResponse.json({ erro: "Categoria é obrigatória" }, { status: 400 })
    }

    const novoProduto = addProduto(nome.trim(), Number.parseFloat(preco), categoria.trim())
    return NextResponse.json(novoProduto, { status: 201 })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao criar produto" }, { status: 500 })
  }
}
