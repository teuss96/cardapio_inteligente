import { NextResponse } from "next/server"
import { updatePedidoStatus } from "@/lib/db"

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { status } = await request.json()

    if (!status) {
      return NextResponse.json({ erro: "Status é obrigatório" }, { status: 400 })
    }

    const pedido = updatePedidoStatus(Number.parseInt(id), status)

    if (!pedido) {
      return NextResponse.json({ erro: "Pedido não encontrado" }, { status: 404 })
    }

    return NextResponse.json(pedido)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao atualizar pedido" }, { status: 500 })
  }
}
