import { NextResponse } from "next/server"
import { updateIngrediente, deleteIngrediente } from "@/lib/db"

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { nome, unidade, quantidade } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome do ingrediente é obrigatório" }, { status: 400 })
    }

    if (!unidade || unidade.trim() === "") {
      return NextResponse.json({ erro: "Unidade é obrigatória" }, { status: 400 })
    }

    if (quantidade === undefined || quantidade < 0) {
      return NextResponse.json({ erro: "Quantidade deve ser maior ou igual a zero" }, { status: 400 })
    }

    const ingrediente = updateIngrediente(
      Number.parseInt(id),
      nome.trim(),
      unidade.trim(),
      Number.parseFloat(quantidade),
    )

    if (!ingrediente) {
      return NextResponse.json({ erro: "Ingrediente não encontrado" }, { status: 404 })
    }

    return NextResponse.json(ingrediente)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao atualizar ingrediente" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const sucesso = deleteIngrediente(Number.parseInt(id))

    if (!sucesso) {
      return NextResponse.json({ erro: "Ingrediente não encontrado" }, { status: 404 })
    }

    return NextResponse.json({ mensagem: "Ingrediente excluído com sucesso" })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao excluir ingrediente" }, { status: 500 })
  }
}
