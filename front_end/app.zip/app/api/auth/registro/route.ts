import { NextResponse } from "next/server"
import { addUsuario, getUsuarioByEmail } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const { nome, email, senha, tipo } = await request.json()

    if (!nome || !email || !senha) {
      return NextResponse.json({ erro: "Todos os campos são obrigatórios" }, { status: 400 })
    }

    if (tipo !== "cliente" && tipo !== "funcionario") {
      return NextResponse.json({ erro: "Tipo de usuário inválido" }, { status: 400 })
    }

    const usuarioExistente = getUsuarioByEmail(email)
    if (usuarioExistente) {
      return NextResponse.json({ erro: "Email já cadastrado" }, { status: 400 })
    }

    const novoUsuario = addUsuario(nome, email, senha, tipo)
    return NextResponse.json(novoUsuario, { status: 201 })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao criar usuário" }, { status: 500 })
  }
}
