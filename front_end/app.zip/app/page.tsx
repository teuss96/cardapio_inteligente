"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useCarrinho } from "@/lib/carrinho-context"
import type { Produto } from "@/lib/db"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function CardapioPage() {
  const router = useRouter()
  const { usuario } = useAuth()
  const { adicionarItem } = useCarrinho()
  const [produtos, setProdutos] = useState<Produto[]>([])
  const [carregando, setCarregando] = useState(true)
  const [produtoSelecionado, setProdutoSelecionado] = useState<Produto | null>(null)

  useEffect(() => {
    fetch("/api/produtos")
      .then((res) => res.json())
      .then((data) => {
        setProdutos(data)
        setCarregando(false)
      })
      .catch((error) => {
        console.error("Erro ao carregar produtos:", error)
        setCarregando(false)
      })
  }, [])

  if (carregando) {
    return (
      <div className="min-h-screen bg-[#F8EECB]">
        <HeaderNav />
        <div className="flex items-center justify-center py-20">
          <div className="text-xl text-[#6E433D]">Carregando...</div>
        </div>
      </div>
    )
  }

  const produtosPorCategoria = produtos.reduce(
    (acc, produto) => {
      if (!acc[produto.categoria]) {
        acc[produto.categoria] = []
      }
      acc[produto.categoria].push(produto)
      return acc
    },
    {} as Record<string, Produto[]>,
  )

  const handleAdicionarAoCarrinho = (produto: Produto) => {
    if (!usuario) {
      router.push("/login")
      return
    }
    adicionarItem(produto)
    setProdutoSelecionado(null)
  }

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-6xl mx-auto px-8 py-12">
        {!usuario && (
          <div className="mb-8 bg-white rounded-lg p-6 shadow-md border-l-4 border-[#F5C065]">
            <p className="text-[#6E433D] text-center">
              Você está navegando como visitante.{" "}
              <button
                onClick={() => router.push("/login")}
                className="text-[#31603D] underline hover:text-[#31603D]/80"
              >
                Faça login
              </button>{" "}
              para fazer pedidos.
            </p>
          </div>
        )}

        {Object.entries(produtosPorCategoria).map(([categoria, items]) => (
          <section key={categoria} className="mb-12">
            <h2 className="text-2xl font-normal text-[#6E433D] mb-6 pb-2 border-b border-[#D4C5A0]">{categoria}</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {items.map((produto) => (
                <button
                  key={produto.id}
                  onClick={() => setProdutoSelecionado(produto)}
                  className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow text-left"
                >
                  <h3 className="text-lg font-normal text-[#6E433D] mb-3">{produto.nome}</h3>
                  <p className="text-sm text-[#6E433D]/70 mb-4 leading-relaxed">
                    Macarrão à base de molho de tomate com frango empanado e queijo mascarpado.
                  </p>
                  <p className="text-lg font-normal text-[#31603D]">R$ {produto.preco.toFixed(2).replace(".", ",")}</p>
                </button>
              ))}
            </div>
          </section>
        ))}

        {produtos.length === 0 && (
          <div className="text-center py-12">
            <p className="text-xl text-[#6E433D]">Nenhum produto cadastrado ainda.</p>
          </div>
        )}
      </main>

      <Dialog open={!!produtoSelecionado} onOpenChange={() => setProdutoSelecionado(null)}>
        <DialogContent className="bg-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-normal text-[#6E433D]">{produtoSelecionado?.nome}</DialogTitle>
          </DialogHeader>

          {produtoSelecionado && (
            <div className="space-y-4">
              <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                <img
                  src="/prato-de-comida-gourmet.jpg"
                  alt={produtoSelecionado.nome}
                  className="w-full h-full object-cover"
                />
              </div>

              <p className="text-sm text-[#6E433D]/70 leading-relaxed">
                Macarrão à base de molho de tomate com frango empanado e queijo mascarpado.
              </p>

              <p className="text-2xl font-normal text-[#31603D]">
                R$ {produtoSelecionado.preco.toFixed(2).replace(".", ",")}
              </p>

              <Button
                onClick={() => handleAdicionarAoCarrinho(produtoSelecionado)}
                className="w-full bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]"
              >
                {usuario ? "ADICIONAR" : "FAZER LOGIN PARA PEDIR"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
