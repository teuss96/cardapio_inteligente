"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import type { Pedido, Produto } from "@/lib/db"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function PedidosFuncionarioPage() {
  const router = useRouter()
  const { usuario, carregando: authCarregando } = useAuth()
  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [produtos, setProdutos] = useState<Produto[]>([])
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    if (!authCarregando && (!usuario || usuario.tipo !== "funcionario")) {
      router.push("/")
      return
    }

    if (usuario) {
      carregarDados()
    }
  }, [usuario, authCarregando, router])

  const carregarDados = async () => {
    try {
      const [pedidosRes, produtosRes] = await Promise.all([fetch("/api/pedidos"), fetch("/api/produtos")])

      const pedidosData = await pedidosRes.json()
      const produtosData = await produtosRes.json()

      setPedidos(pedidosData)
      setProdutos(produtosData)
      setCarregando(false)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      setCarregando(false)
    }
  }

  const getProdutoNome = (produtoId: number) => {
    const produto = produtos.find((p) => p.id === produtoId)
    return produto?.nome || "Produto não encontrado"
  }

  const getStatusColor = (status: Pedido["status"]) => {
    switch (status) {
      case "pendente":
        return "bg-[#F5C065] text-[#6E433D]"
      case "preparando":
        return "bg-[#31603D] text-[#F8EECB]"
      case "pronto":
        return "bg-[#31603D] text-[#F8EECB]"
      case "entregue":
        return "bg-[#6E433D] text-[#F8EECB]"
    }
  }

  const handleAtualizarStatus = async (pedidoId: number, novoStatus: Pedido["status"]) => {
    try {
      const response = await fetch(`/api/pedidos/${pedidoId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: novoStatus }),
      })

      if (response.ok) {
        carregarDados()
      } else {
        alert("Erro ao atualizar status do pedido")
      }
    } catch (error) {
      console.error("Erro ao atualizar status:", error)
      alert("Erro ao atualizar status do pedido")
    }
  }

  const getProximoStatus = (statusAtual: Pedido["status"]): Pedido["status"] | null => {
    switch (statusAtual) {
      case "pendente":
        return "preparando"
      case "preparando":
        return "pronto"
      case "pronto":
        return "entregue"
      case "entregue":
        return null
    }
  }

  const getTextoProximoStatus = (statusAtual: Pedido["status"]): string => {
    switch (statusAtual) {
      case "pendente":
        return "Iniciar Preparo"
      case "preparando":
        return "Marcar como Pronto"
      case "pronto":
        return "Marcar como Entregue"
      case "entregue":
        return "Concluído"
    }
  }

  if (authCarregando || carregando) {
    return (
      <div className="min-h-screen bg-[#F8EECB]">
        <HeaderNav />
        <div className="flex items-center justify-center py-20">
          <div className="text-xl text-[#6E433D]">Carregando...</div>
        </div>
      </div>
    )
  }

  const pedidosAtivos = pedidos.filter((p) => p.status !== "entregue")
  const pedidosConcluidos = pedidos.filter((p) => p.status === "entregue")

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-6xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-normal text-[#6E433D] mb-2">Gerenciamento de Pedidos</h1>
          <p className="text-[#6E433D]/70">Acompanhe e atualize o status dos pedidos</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-normal text-[#6E433D] mb-6 pb-2 border-b border-[#D4C5A0]">
              Pedidos em Andamento ({pedidosAtivos.length})
            </h2>

            {pedidosAtivos.length === 0 ? (
              <p className="text-center py-8 text-[#6E433D]/70">Nenhum pedido em andamento</p>
            ) : (
              <div className="space-y-4">
                {pedidosAtivos.map((pedido) => (
                  <div key={pedido.id} className="bg-white rounded-lg p-6 shadow-md">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-normal text-lg text-[#6E433D]">Pedido #{pedido.id}</h3>
                        <p className="text-sm text-[#6E433D]/70">
                          {new Date(pedido.dataCriacao).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <Badge className={`${getStatusColor(pedido.status)}`}>
                        {pedido.status.charAt(0).toUpperCase() + pedido.status.slice(1)}
                      </Badge>
                    </div>

                    <div className="space-y-1 mb-3">
                      {pedido.items.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm text-[#6E433D]">
                          <span>
                            {item.quantidade}x {getProdutoNome(item.produtoId)}
                          </span>
                          <span className="text-[#31603D] font-normal">
                            R$ {(item.preco * item.quantidade).toFixed(2).replace(".", ",")}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-[#D4C5A0] pt-3 mb-3 flex justify-between items-center">
                      <span className="font-normal text-[#6E433D]">Total:</span>
                      <span className="font-normal text-lg text-[#31603D]">
                        R$ {pedido.total.toFixed(2).replace(".", ",")}
                      </span>
                    </div>

                    {getProximoStatus(pedido.status) && (
                      <Button
                        onClick={() => handleAtualizarStatus(pedido.id, getProximoStatus(pedido.status)!)}
                        className="w-full bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]"
                        size="sm"
                      >
                        {getTextoProximoStatus(pedido.status)}
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h2 className="text-2xl font-normal text-[#6E433D] mb-6 pb-2 border-b border-[#D4C5A0]">
              Pedidos Concluídos ({pedidosConcluidos.length})
            </h2>

            {pedidosConcluidos.length === 0 ? (
              <p className="text-center py-8 text-[#6E433D]/70">Nenhum pedido concluído ainda</p>
            ) : (
              <div className="space-y-4 max-h-[600px] overflow-y-auto">
                {pedidosConcluidos.map((pedido) => (
                  <div key={pedido.id} className="bg-white rounded-lg p-6 shadow-md opacity-75">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-normal text-lg text-[#6E433D]">Pedido #{pedido.id}</h3>
                        <p className="text-sm text-[#6E433D]/70">
                          {new Date(pedido.dataCriacao).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <Badge className="bg-[#6E433D] text-[#F8EECB]">Entregue</Badge>
                    </div>

                    <div className="space-y-1 mb-3">
                      {pedido.items.map((item, index) => (
                        <div key={index} className="flex justify-between text-sm text-[#6E433D]">
                          <span>
                            {item.quantidade}x {getProdutoNome(item.produtoId)}
                          </span>
                          <span className="text-[#31603D] font-normal">
                            R$ {(item.preco * item.quantidade).toFixed(2).replace(".", ",")}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="border-t border-[#D4C5A0] pt-3 flex justify-between items-center">
                      <span className="font-normal text-[#6E433D]">Total:</span>
                      <span className="font-normal text-lg text-[#31603D]">
                        R$ {pedido.total.toFixed(2).replace(".", ",")}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}
