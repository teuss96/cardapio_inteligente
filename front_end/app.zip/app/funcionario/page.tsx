"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import type { Produto, Categoria, Ingrediente } from "@/lib/db"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Pencil, Trash2, Plus } from "lucide-react"

export default function FuncionarioPage() {
  const router = useRouter()
  const { usuario, logout, carregando: authCarregando } = useAuth()

  const [produtos, setProdutos] = useState<Produto[]>([])
  const [categorias, setCategorias] = useState<Categoria[]>([])
  const [ingredientes, setIngredientes] = useState<Ingrediente[]>([])

  const [mostrarFormProduto, setMostrarFormProduto] = useState(false)
  const [editandoProduto, setEditandoProduto] = useState<Produto | null>(null)
  const [nomeProduto, setNomeProduto] = useState("")
  const [precoProduto, setPrecoProduto] = useState("")
  const [categoriaProduto, setCategoriaProduto] = useState("")

  const [mostrarFormIngrediente, setMostrarFormIngrediente] = useState(false)
  const [editandoIngrediente, setEditandoIngrediente] = useState<Ingrediente | null>(null)
  const [nomeIngrediente, setNomeIngrediente] = useState("")
  const [unidadeIngrediente, setUnidadeIngrediente] = useState("")
  const [quantidadeIngrediente, setQuantidadeIngrediente] = useState("")

  useEffect(() => {
    if (!authCarregando && (!usuario || usuario.tipo !== "funcionario")) {
      router.push("/")
      return
    }

    if (usuario) {
      carregarDados()
    }
  }, [usuario, authCarregando, router])

  const carregarDados = async () => {
    try {
      const [produtosRes, categoriasRes, ingredientesRes] = await Promise.all([
        fetch("/api/produtos"),
        fetch("/api/categorias"),
        fetch("/api/ingredientes"),
      ])

      const produtosData = await produtosRes.json()
      const categoriasData = await categoriasRes.json()
      const ingredientesData = await ingredientesRes.json()

      setProdutos(produtosData)
      setCategorias(categoriasData)
      setIngredientes(ingredientesData)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
    }
  }

  const handleSubmitProduto = async (e: React.FormEvent) => {
    e.preventDefault()

    const dados = {
      nome: nomeProduto,
      preco: Number.parseFloat(precoProduto),
      categoria: categoriaProduto,
    }

    try {
      if (editandoProduto) {
        await fetch(`/api/produtos/${editandoProduto.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dados),
        })
      } else {
        await fetch("/api/produtos", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dados),
        })
      }

      carregarDados()
      limparFormProduto()
    } catch (error) {
      console.error("Erro ao salvar produto:", error)
    }
  }

  const handleExcluirProduto = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este produto?")) return

    try {
      await fetch(`/api/produtos/${id}`, { method: "DELETE" })
      carregarDados()
    } catch (error) {
      console.error("Erro ao excluir produto:", error)
    }
  }

  const handleSubmitIngrediente = async (e: React.FormEvent) => {
    e.preventDefault()

    const dados = {
      nome: nomeIngrediente,
      unidade: unidadeIngrediente,
      quantidade: Number.parseFloat(quantidadeIngrediente),
    }

    try {
      if (editandoIngrediente) {
        await fetch(`/api/ingredientes/${editandoIngrediente.id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dados),
        })
      } else {
        await fetch("/api/ingredientes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dados),
        })
      }

      carregarDados()
      limparFormIngrediente()
    } catch (error) {
      console.error("Erro ao salvar ingrediente:", error)
    }
  }

  const handleExcluirIngrediente = async (id: number) => {
    if (!confirm("Tem certeza que deseja excluir este ingrediente?")) return

    try {
      await fetch(`/api/ingredientes/${id}`, { method: "DELETE" })
      carregarDados()
    } catch (error) {
      console.error("Erro ao excluir ingrediente:", error)
    }
  }

  const limparFormProduto = () => {
    setNomeProduto("")
    setPrecoProduto("")
    setCategoriaProduto("")
    setEditandoProduto(null)
    setMostrarFormProduto(false)
  }

  const limparFormIngrediente = () => {
    setNomeIngrediente("")
    setUnidadeIngrediente("")
    setQuantidadeIngrediente("")
    setEditandoIngrediente(null)
    setMostrarFormIngrediente(false)
  }

  if (authCarregando) {
    return (
      <div className="min-h-screen bg-[#F8EECB]">
        <HeaderNav />
        <div className="flex items-center justify-center py-20">
          <div className="text-xl text-[#6E433D]">Carregando...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-6xl mx-auto px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-normal text-[#6E433D] mb-2">Painel do Funcionário</h1>
          <p className="text-[#6E433D]/70">Gerencie produtos, ingredientes e pedidos</p>
        </div>

        <div className="mb-6 flex gap-4">
          <Button
            onClick={() => router.push("/funcionario/pedidos")}
            className="bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]"
          >
            Ver Pedidos
          </Button>
        </div>

        <Tabs defaultValue="produtos" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6 bg-white">
            <TabsTrigger value="produtos">Produtos</TabsTrigger>
            <TabsTrigger value="ingredientes">Ingredientes</TabsTrigger>
          </TabsList>

          <TabsContent value="produtos">
            <div className="mb-6">
              <Button
                onClick={() => setMostrarFormProduto(!mostrarFormProduto)}
                className="bg-[#D23D2D] hover:bg-[#D23D2D]/90 text-[#F8EECB]"
              >
                <Plus className="w-4 h-4 mr-2" />
                {mostrarFormProduto ? "Cancelar" : "Adicionar Produto"}
              </Button>
            </div>

            {mostrarFormProduto && (
              <div className="bg-white rounded-lg p-6 shadow-md mb-8">
                <h2 className="text-xl font-normal text-[#6E433D] mb-4">
                  {editandoProduto ? "Editar Produto" : "Novo Produto"}
                </h2>
                <form onSubmit={handleSubmitProduto} className="space-y-4">
                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Nome do Produto</label>
                    <Input
                      value={nomeProduto}
                      onChange={(e) => setNomeProduto(e.target.value)}
                      className="bg-[#F8EECB] border-[#D4C5A0]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Preço (R$)</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={precoProduto}
                      onChange={(e) => setPrecoProduto(e.target.value)}
                      className="bg-[#F8EECB] border-[#D4C5A0]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Categoria</label>
                    <select
                      value={categoriaProduto}
                      onChange={(e) => setCategoriaProduto(e.target.value)}
                      className="w-full px-3 py-2 border border-[#D4C5A0] rounded-md bg-[#F8EECB] text-[#6E433D]"
                      required
                    >
                      <option value="">Selecione uma categoria</option>
                      {categorias.map((cat) => (
                        <option key={cat.id} value={cat.nome}>
                          {cat.nome}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex gap-2">
                    <Button type="submit" className="bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]">
                      {editandoProduto ? "Atualizar" : "Salvar"}
                    </Button>
                    <Button
                      type="button"
                      onClick={limparFormProduto}
                      className="bg-white hover:bg-gray-50 text-[#6E433D] border border-[#D4C5A0]"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </div>
            )}

            <div className="space-y-4">
              {produtos.map((produto) => (
                <div key={produto.id} className="bg-white rounded-lg p-6 shadow-md flex justify-between items-center">
                  <div className="flex-1">
                    <h3 className="text-lg font-normal text-[#6E433D]">{produto.nome}</h3>
                    <p className="text-sm text-[#6E433D]/70">{produto.categoria}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-lg font-normal text-[#31603D]">
                      R$ {produto.preco.toFixed(2).replace(".", ",")}
                    </span>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() =>
                          setEditandoProduto(produto) ||
                          setNomeProduto(produto.nome) ||
                          setPrecoProduto(produto.preco.toString()) ||
                          setCategoriaProduto(produto.categoria) ||
                          setMostrarFormProduto(true)
                        }
                        className="bg-[#F5C065] hover:bg-[#F5C065]/90 text-[#6E433D]"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleExcluirProduto(produto.id)}
                        className="bg-[#D23D2D] hover:bg-[#D23D2D]/90 text-[#F8EECB]"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}

              {produtos.length === 0 && (
                <p className="text-center py-8 text-[#6E433D]/70">Nenhum produto cadastrado ainda.</p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="ingredientes">
            <div className="mb-6">
              <Button
                onClick={() => setMostrarFormIngrediente(!mostrarFormIngrediente)}
                className="bg-[#D23D2D] hover:bg-[#D23D2D]/90 text-[#F8EECB]"
              >
                <Plus className="w-4 h-4 mr-2" />
                {mostrarFormIngrediente ? "Cancelar" : "Adicionar Ingrediente"}
              </Button>
            </div>

            {mostrarFormIngrediente && (
              <div className="bg-white rounded-lg p-6 shadow-md mb-8">
                <h2 className="text-xl font-normal text-[#6E433D] mb-4">
                  {editandoIngrediente ? "Editar Ingrediente" : "Novo Ingrediente"}
                </h2>
                <form onSubmit={handleSubmitIngrediente} className="space-y-4">
                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Nome do Ingrediente</label>
                    <Input
                      value={nomeIngrediente}
                      onChange={(e) => setNomeIngrediente(e.target.value)}
                      className="bg-[#F8EECB] border-[#D4C5A0]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Unidade</label>
                    <Input
                      value={unidadeIngrediente}
                      onChange={(e) => setUnidadeIngrediente(e.target.value)}
                      className="bg-[#F8EECB] border-[#D4C5A0]"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-normal text-[#6E433D] mb-2">Quantidade</label>
                    <Input
                      type="number"
                      step="0.01"
                      value={quantidadeIngrediente}
                      onChange={(e) => setQuantidadeIngrediente(e.target.value)}
                      className="bg-[#F8EECB] border-[#D4C5A0]"
                      required
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button type="submit" className="bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]">
                      {editandoIngrediente ? "Atualizar" : "Salvar"}
                    </Button>
                    <Button
                      type="button"
                      onClick={limparFormIngrediente}
                      className="bg-white hover:bg-gray-50 text-[#6E433D] border border-[#D4C5A0]"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </div>
            )}

            <div className="space-y-4">
              {ingredientes.map((ingrediente) => (
                <div
                  key={ingrediente.id}
                  className="bg-white rounded-lg p-6 shadow-md flex justify-between items-center"
                >
                  <div className="flex-1">
                    <h3 className="text-lg font-normal text-[#6E433D]">{ingrediente.nome}</h3>
                    <p className="text-sm text-[#6E433D]/70">
                      {ingrediente.quantidade} {ingrediente.unidade}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() =>
                        setEditandoIngrediente(ingrediente) ||
                        setNomeIngrediente(ingrediente.nome) ||
                        setUnidadeIngrediente(ingrediente.unidade) ||
                        setQuantidadeIngrediente(ingrediente.quantidade.toString()) ||
                        setMostrarFormIngrediente(true)
                      }
                      className="bg-[#F5C065] hover:bg-[#F5C065]/90 text-[#6E433D]"
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleExcluirIngrediente(ingrediente.id)}
                      className="bg-[#D23D2D] hover:bg-[#D23D2D]/90 text-[#F8EECB]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}

              {ingredientes.length === 0 && (
                <p className="text-center py-8 text-[#6E433D]/70">Nenhum ingrediente cadastrado ainda.</p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
