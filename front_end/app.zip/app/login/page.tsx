"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function LoginPage() {
  const router = useRouter()
  const { login, registro } = useAuth()
  const [tipoUsuario, setTipoUsuario] = useState<"cliente" | "funcionario">("cliente")
  const [modoRegistro, setModoRegistro] = useState(false)

  const [email, setEmail] = useState("")
  const [senha, setSenha] = useState("")
  const [nome, setNome] = useState("")
  const [erro, setErro] = useState("")
  const [carregando, setCarregando] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErro("")
    setCarregando(true)

    let sucesso = false

    if (modoRegistro) {
      sucesso = await registro(nome, email, senha, tipoUsuario)
      if (!sucesso) {
        setErro("Erro ao criar conta. Email pode já estar cadastrado.")
      }
    } else {
      sucesso = await login(email, senha)
      if (!sucesso) {
        setErro("Email ou senha inválidos")
      }
    }

    if (sucesso) {
      if (tipoUsuario === "funcionario") {
        router.push("/funcionario")
      } else {
        router.push("/")
      }
    }

    setCarregando(false)
  }

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-2xl mx-auto px-8 py-12">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-normal text-[#6E433D] text-center mb-8">
            {modoRegistro ? "Criar Conta" : "Login"}
          </h1>

          <div className="flex gap-4 mb-8">
            <button
              type="button"
              onClick={() => setTipoUsuario("cliente")}
              className={`flex-1 py-3 rounded-lg font-normal transition-colors ${
                tipoUsuario === "cliente"
                  ? "bg-[#31603D] text-[#F8EECB]"
                  : "bg-[#F8EECB] text-[#6E433D] border border-[#D4C5A0]"
              }`}
            >
              Cliente
            </button>
            <button
              type="button"
              onClick={() => setTipoUsuario("funcionario")}
              className={`flex-1 py-3 rounded-lg font-normal transition-colors ${
                tipoUsuario === "funcionario"
                  ? "bg-[#31603D] text-[#F8EECB]"
                  : "bg-[#F8EECB] text-[#6E433D] border border-[#D4C5A0]"
              }`}
            >
              Funcionário
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {modoRegistro && (
              <div>
                <label className="block text-sm font-normal text-[#6E433D] mb-2">Nome:</label>
                <Input
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  className="bg-[#F8EECB] border-[#D4C5A0]"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-normal text-[#6E433D] mb-2">Email:</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-[#F8EECB] border-[#D4C5A0]"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-normal text-[#6E433D] mb-2">Senha:</label>
              <Input
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="bg-[#F8EECB] border-[#D4C5A0]"
                required
              />
            </div>

            {erro && <p className="text-sm text-[#D23D2D]">{erro}</p>}

            <Button
              type="submit"
              className="w-full bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB] py-6 text-lg"
              disabled={carregando}
            >
              {carregando ? "PROCESSANDO..." : modoRegistro ? "CRIAR CONTA" : "ENTRAR"}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => {
                setModoRegistro(!modoRegistro)
                setErro("")
              }}
              className="text-sm text-[#31603D] hover:underline"
            >
              {modoRegistro ? "Já tem uma conta? Faça login" : "Não tem uma conta? Cadastre-se"}
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
