"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import type { Pedido, Produto } from "@/lib/db"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function PedidosPage() {
  const router = useRouter()
  const { usuario, carregando: authCarregando } = useAuth()
  const [pedidos, setPedidos] = useState<Pedido[]>([])
  const [produtos, setProdutos] = useState<Produto[]>([])
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    if (!authCarregando && (!usuario || usuario.tipo !== "cliente")) {
      router.push("/")
      return
    }

    if (usuario) {
      Promise.all([fetch("/api/pedidos").then((res) => res.json()), fetch("/api/produtos").then((res) => res.json())])
        .then(([pedidosData, produtosData]) => {
          const meusPedidos = pedidosData.filter((p: Pedido) => p.clienteId === usuario.id)
          setPedidos(meusPedidos)
          setProdutos(produtosData)
          setCarregando(false)
        })
        .catch((error) => {
          console.error("Erro ao carregar pedidos:", error)
          setCarregando(false)
        })
    }
  }, [usuario, authCarregando, router])

  const getProdutoNome = (produtoId: number) => {
    const produto = produtos.find((p) => p.id === produtoId)
    return produto?.nome || "Produto não encontrado"
  }

  const getStatusColor = (status: Pedido["status"]) => {
    switch (status) {
      case "pendente":
        return "bg-[#F5C065] text-[#6E433D]"
      case "preparando":
        return "bg-[#31603D] text-[#F8EECB]"
      case "pronto":
        return "bg-[#31603D] text-[#F8EECB]"
      case "entregue":
        return "bg-[#6E433D] text-[#F8EECB]"
    }
  }

  if (authCarregando || carregando) {
    return (
      <div className="min-h-screen bg-[#F8EECB]">
        <HeaderNav />
        <div className="flex items-center justify-center py-20">
          <div className="text-xl text-[#6E433D]">Carregando...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-4xl mx-auto px-8 py-12">
        <h1 className="text-3xl font-normal text-[#6E433D] mb-8">Meus Pedidos</h1>

        {pedidos.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <p className="text-xl text-[#6E433D]/70 mb-4">Você ainda não fez nenhum pedido</p>
            <Button onClick={() => router.push("/")} className="bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]">
              Ver Cardápio
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {pedidos.map((pedido) => (
              <div key={pedido.id} className="bg-white rounded-lg p-6 shadow-md">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-normal text-lg text-[#6E433D]">Pedido #{pedido.id}</h3>
                    <p className="text-sm text-[#6E433D]/70">{new Date(pedido.dataCriacao).toLocaleString("pt-BR")}</p>
                  </div>
                  <Badge className={`${getStatusColor(pedido.status)}`}>
                    {pedido.status.charAt(0).toUpperCase() + pedido.status.slice(1)}
                  </Badge>
                </div>

                <div className="space-y-2 mb-4">
                  {pedido.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm text-[#6E433D]">
                      <span>
                        {item.quantidade}x {getProdutoNome(item.produtoId)}
                      </span>
                      <span className="text-[#31603D] font-normal">
                        R$ {(item.preco * item.quantidade).toFixed(2).replace(".", ",")}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-[#D4C5A0] pt-3 flex justify-between items-center">
                  <span className="font-normal text-lg text-[#6E433D]">Total:</span>
                  <span className="font-normal text-xl text-[#31603D]">
                    R$ {pedido.total.toFixed(2).replace(".", ",")}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
