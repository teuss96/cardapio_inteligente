"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useCarrinho } from "@/lib/carrinho-context"
import { HeaderNav } from "@/components/header-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, Plus, Minus } from "lucide-react"
import { useState } from "react"

export default function CarrinhoPage() {
  const router = useRouter()
  const { usuario, carregando: authCarregando } = useAuth()
  const { items, removerItem, atualizarQuantidade, limparCarrinho, total } = useCarrinho()
  const [finalizando, setFinalizando] = useState(false)

  useEffect(() => {
    if (!authCarregando && (!usuario || usuario.tipo !== "cliente")) {
      router.push("/")
    }
  }, [usuario, authCarregando, router])

  const handleFinalizarPedido = async () => {
    if (items.length === 0) return

    setFinalizando(true)

    try {
      const itemsPedido = items.map((item) => ({
        produtoId: item.id,
        quantidade: item.quantidade,
        preco: item.preco,
      }))

      const response = await fetch("/api/pedidos", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clienteId: usuario?.id,
          items: itemsPedido,
        }),
      })

      if (response.ok) {
        limparCarrinho()
        router.push("/cliente/pedidos")
      } else {
        alert("Erro ao finalizar pedido")
      }
    } catch (error) {
      console.error("Erro ao finalizar pedido:", error)
      alert("Erro ao finalizar pedido")
    } finally {
      setFinalizando(false)
    }
  }

  if (authCarregando) {
    return (
      <div className="min-h-screen bg-[#F8EECB]">
        <HeaderNav />
        <div className="flex items-center justify-center py-20">
          <div className="text-xl text-[#6E433D]">Carregando...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-4xl mx-auto px-8 py-12">
        <h1 className="text-3xl font-normal text-[#6E433D] mb-8">Meu Carrinho</h1>

        {items.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-md">
            <p className="text-xl text-[#6E433D]/70 mb-4">Seu carrinho está vazio</p>
            <Button onClick={() => router.push("/")} className="bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB]">
              Ver Cardápio
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-6 bg-white rounded-lg shadow-md">
                <div className="flex-1">
                  <h3 className="font-normal text-lg text-[#6E433D]">{item.nome}</h3>
                  <p className="text-sm text-[#6E433D]/70">{item.categoria}</p>
                  <p className="text-[#31603D] font-normal mt-1">R$ {item.preco.toFixed(2).replace(".", ",")}</p>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      onClick={() => atualizarQuantidade(item.id, item.quantidade - 1)}
                      className="bg-[#F5C065] hover:bg-[#F5C065]/90 text-[#6E433D] h-8 w-8 p-0"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <Input
                      type="number"
                      value={item.quantidade}
                      onChange={(e) => atualizarQuantidade(item.id, Number.parseInt(e.target.value) || 1)}
                      className="w-16 text-center bg-[#F8EECB] border-[#D4C5A0]"
                      min="1"
                    />
                    <Button
                      size="sm"
                      onClick={() => atualizarQuantidade(item.id, item.quantidade + 1)}
                      className="bg-[#F5C065] hover:bg-[#F5C065]/90 text-[#6E433D] h-8 w-8 p-0"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="text-lg font-normal text-[#31603D] w-24 text-right">
                    R$ {(item.preco * item.quantidade).toFixed(2).replace(".", ",")}
                  </div>

                  <Button
                    size="sm"
                    onClick={() => removerItem(item.id)}
                    className="bg-[#D23D2D] hover:bg-[#D23D2D]/90 text-[#F8EECB]"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}

            <div className="bg-white rounded-lg shadow-md p-6 mt-6">
              <div className="flex justify-between items-center mb-6">
                <span className="text-2xl font-normal text-[#6E433D]">Total:</span>
                <span className="text-3xl font-normal text-[#31603D]">R$ {total.toFixed(2).replace(".", ",")}</span>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleFinalizarPedido}
                  className="flex-1 bg-[#31603D] hover:bg-[#31603D]/90 text-[#F8EECB] text-lg py-6"
                  disabled={finalizando}
                >
                  {finalizando ? "Finalizando..." : "Finalizar Pedido"}
                </Button>
                <Button
                  onClick={limparCarrinho}
                  className="py-6 bg-white hover:bg-gray-50 text-[#6E433D] border border-[#D4C5A0]"
                >
                  Limpar Carrinho
                </Button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
