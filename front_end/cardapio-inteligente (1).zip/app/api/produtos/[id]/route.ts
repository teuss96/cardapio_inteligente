import { NextResponse } from "next/server"
import { updateProduto, deleteProduto } from "@/lib/db"

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { nome, preco, categoria } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome do produto é obrigatório" }, { status: 400 })
    }

    if (!preco || preco <= 0) {
      return NextResponse.json({ erro: "Preço deve ser maior que zero" }, { status: 400 })
    }

    if (!categoria || categoria.trim() === "") {
      return NextResponse.json({ erro: "Categoria é obrigatória" }, { status: 400 })
    }

    const produto = updateProduto(Number.parseInt(id), nome.trim(), Number.parseFloat(preco), categoria.trim())

    if (!produto) {
      return NextResponse.json({ erro: "Produto não encontrado" }, { status: 404 })
    }

    return NextResponse.json(produto)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao atualizar produto" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const sucesso = deleteProduto(Number.parseInt(id))

    if (!sucesso) {
      return NextResponse.json({ erro: "Produto não encontrado" }, { status: 404 })
    }

    return NextResponse.json({ mensagem: "Produto excluído com sucesso" })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao excluir produto" }, { status: 500 })
  }
}
