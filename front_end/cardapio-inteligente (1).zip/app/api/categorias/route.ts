import { NextResponse } from "next/server"
import { getCategorias, addCategoria } from "@/lib/db"

export async function GET() {
  try {
    const categorias = getCategorias()
    return NextResponse.json(categorias)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao buscar categorias" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { nome } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome da categoria é obrigatório" }, { status: 400 })
    }

    const novaCategoria = addCategoria(nome.trim())
    return NextResponse.json(novaCategoria, { status: 201 })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao criar categoria" }, { status: 500 })
  }
}
