import { NextResponse } from "next/server"
import { updateCategoria, deleteCategoria } from "@/lib/db"

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const { nome } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome da categoria é obrigatório" }, { status: 400 })
    }

    const categoria = updateCategoria(Number.parseInt(id), nome.trim())

    if (!categoria) {
      return NextResponse.json({ erro: "Categoria não encontrada" }, { status: 404 })
    }

    return NextResponse.json(categoria)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao atualizar categoria" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const sucesso = deleteCategoria(Number.parseInt(id))

    if (!sucesso) {
      return NextResponse.json({ erro: "Categoria não encontrada" }, { status: 404 })
    }

    return NextResponse.json({ mensagem: "Categoria excluída com sucesso" })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao excluir categoria" }, { status: 500 })
  }
}
