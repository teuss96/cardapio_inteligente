import { NextResponse } from "next/server"
import { autenticarUsuario } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const { email, senha } = await request.json()

    if (!email || !senha) {
      return NextResponse.json({ erro: "Email e senha são obrigatórios" }, { status: 400 })
    }

    const usuario = autenticarUsuario(email, senha)

    if (!usuario) {
      return NextResponse.json({ erro: "Email ou senha inválidos" }, { status: 401 })
    }

    return NextResponse.json(usuario)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao fazer login" }, { status: 500 })
  }
}
