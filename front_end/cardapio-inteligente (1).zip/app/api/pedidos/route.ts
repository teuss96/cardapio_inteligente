import { NextResponse } from "next/server"
import { addPedido, getPedidos } from "@/lib/db"

export async function GET() {
  try {
    const pedidos = getPedidos()
    return NextResponse.json(pedidos)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao buscar pedidos" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { clienteId, items } = await request.json()

    if (!clienteId || !items || items.length === 0) {
      return NextResponse.json({ erro: "Dados do pedido inválidos" }, { status: 400 })
    }

    const novoPedido = addPedido(clienteId, items)
    return NextResponse.json(novoPedido, { status: 201 })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao criar pedido" }, { status: 500 })
  }
}
