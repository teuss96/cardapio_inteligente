import { NextResponse } from "next/server"
import { getIngredientes, addIngrediente } from "@/lib/db"

export async function GET() {
  try {
    const ingredientes = getIngredientes()
    return NextResponse.json(ingredientes)
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao buscar ingredientes" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { nome, unidade, quantidade } = await request.json()

    if (!nome || nome.trim() === "") {
      return NextResponse.json({ erro: "Nome do ingrediente é obrigatório" }, { status: 400 })
    }

    if (!unidade || unidade.trim() === "") {
      return NextResponse.json({ erro: "Unidade é obrigatória" }, { status: 400 })
    }

    if (quantidade === undefined || quantidade < 0) {
      return NextResponse.json({ erro: "Quantidade deve ser maior ou igual a zero" }, { status: 400 })
    }

    const novoIngrediente = addIngrediente(nome.trim(), unidade.trim(), Number.parseFloat(quantidade))
    return NextResponse.json(novoIngrediente, { status: 201 })
  } catch (error) {
    return NextResponse.json({ erro: "Erro ao criar ingrediente" }, { status: 500 })
  }
}
