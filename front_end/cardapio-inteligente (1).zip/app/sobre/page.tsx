"use client"

import { HeaderNav } from "@/components/header-nav"

export default function SobrePage() {
  return (
    <div className="min-h-screen bg-[#F8EECB]">
      <HeaderNav />

      <main className="max-w-4xl mx-auto px-8 py-12">
        <section className="mb-12">
          <h1 className="text-2xl font-normal text-[#6E433D] mb-6 pb-2 border-b border-[#D4C5A0]">
            Sobre - Restaurante credenciado
          </h1>

          <div className="space-y-6 text-[#6E433D]">
            <div>
              <h2 className="text-lg font-normal mb-2">Cantos do Mar</h2>
              <p className="text-sm leading-relaxed">Oferecendo o sabor da imersão marítima!</p>
            </div>

            <div className="text-sm leading-relaxed">
              <p className="mb-2">Endereço: Avenida Cais do Porto, 00, Carais, Pernambuco, Brasil</p>
              <p>Telefone: (81) 1111-2222</p>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-normal text-[#6E433D] mb-6 pb-2 border-b border-[#D4C5A0]">
            Créditos do Projeto - Cardápio Inteligente
          </h2>

          <div className="space-y-6 text-[#6E433D]">
            <div>
              <h3 className="text-lg font-normal mb-2">Equipe do Projeto</h3>
            </div>

            <ul className="space-y-2 text-sm leading-relaxed list-disc list-inside">
              <li>Arthur Apolinário</li>
              <li>João Carlos Mafra</li>
              <li>Mateus Reinaux</li>
              <li>Isaac Alessandro</li>
              <li>Miguel Lopes</li>
              <li>Pedro Henrique</li>
              <li>Renata Mariana</li>
              <li>Marina Marinho</li>
            </ul>

            <p className="text-xs text-[#6E433D]/60 mt-8">
              Centro de Estudos e Sistemas Avançados do Recife (CESAR) / Serviços de Projeto 1 / 2025.2
            </p>
          </div>
        </section>
      </main>
    </div>
  )
}
