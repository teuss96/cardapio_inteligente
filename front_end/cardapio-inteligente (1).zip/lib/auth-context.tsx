"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Usuario } from "@/lib/db"

interface AuthContextType {
  usuario: Usuario | null
  login: (email: string, senha: string) => Promise<boolean>
  registro: (nome: string, email: string, senha: string, tipo: "cliente" | "funcionario") => Promise<boolean>
  logout: () => void
  carregando: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(null)
  const [carregando, setCarregando] = useState(true)

  useEffect(() => {
    const usuarioSalvo = localStorage.getItem("usuario")
    if (usuarioSalvo) {
      setUsuario(JSON.parse(usuarioSalvo))
    }
    setCarregando(false)
  }, [])

  const login = async (email: string, senha: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, senha }),
      })

      if (!response.ok) return false

      const usuarioData = await response.json()
      setUsuario(usuarioData)
      localStorage.setItem("usuario", JSON.stringify(usuarioData))
      return true
    } catch (error) {
      console.error("Erro ao fazer login:", error)
      return false
    }
  }

  const registro = async (
    nome: string,
    email: string,
    senha: string,
    tipo: "cliente" | "funcionario",
  ): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/registro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, senha, tipo }),
      })

      if (!response.ok) return false

      const usuarioData = await response.json()
      setUsuario(usuarioData)
      localStorage.setItem("usuario", JSON.stringify(usuarioData))
      return true
    } catch (error) {
      console.error("Erro ao registrar:", error)
      return false
    }
  }

  const logout = () => {
    setUsuario(null)
    localStorage.removeItem("usuario")
  }

  return (
    <AuthContext.Provider value={{ usuario, login, registro, logout, carregando }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider")
  }
  return context
}
