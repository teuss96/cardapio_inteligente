"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Produto } from "@/lib/db"

interface ItemCarrinho extends Produto {
  quantidade: number
}

interface CarrinhoContextType {
  items: ItemCarrinho[]
  adicionarItem: (produto: Produto) => void
  removerItem: (produtoId: number) => void
  atualizarQuantidade: (produtoId: number, quantidade: number) => void
  limparCarrinho: () => void
  total: number
}

const CarrinhoContext = createContext<CarrinhoContextType | undefined>(undefined)

export function CarrinhoProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ItemCarrinho[]>([])

  useEffect(() => {
    const carrinhoSalvo = localStorage.getItem("carrinho")
    if (carrinhoSalvo) {
      setItems(JSON.parse(carrinhoSalvo))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("carrinho", JSON.stringify(items))
  }, [items])

  const adicionarItem = (produto: Produto) => {
    setItems((prev) => {
      const itemExistente = prev.find((item) => item.id === produto.id)
      if (itemExistente) {
        return prev.map((item) => (item.id === produto.id ? { ...item, quantidade: item.quantidade + 1 } : item))
      }
      return [...prev, { ...produto, quantidade: 1 }]
    })
  }

  const removerItem = (produtoId: number) => {
    setItems((prev) => prev.filter((item) => item.id !== produtoId))
  }

  const atualizarQuantidade = (produtoId: number, quantidade: number) => {
    if (quantidade <= 0) {
      removerItem(produtoId)
      return
    }
    setItems((prev) => prev.map((item) => (item.id === produtoId ? { ...item, quantidade } : item)))
  }

  const limparCarrinho = () => {
    setItems([])
  }

  const total = items.reduce((sum, item) => sum + item.preco * item.quantidade, 0)

  return (
    <CarrinhoContext.Provider value={{ items, adicionarItem, removerItem, atualizarQuantidade, limparCarrinho, total }}>
      {children}
    </CarrinhoContext.Provider>
  )
}

export function useCarrinho() {
  const context = useContext(CarrinhoContext)
  if (context === undefined) {
    throw new Error("useCarrinho deve ser usado dentro de um CarrinhoProvider")
  }
  return context
}
