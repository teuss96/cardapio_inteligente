"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth-context"

export function HeaderNav() {
  const pathname = usePathname()
  const { usuario, logout } = useAuth()

  const links = [
    { href: "/", label: "HOME" },
    { href: "/sobre", label: "SOBRE" },
  ]

  return (
    <header className="bg-[#6E433D] text-[#F8EECB] py-4 px-6 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link href="/" className="text-xl font-normal tracking-wide">
          Cardápio Inteligente
        </Link>

        <nav className="flex gap-8 items-center">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`text-sm font-light tracking-wide hover:text-[#F5C065] transition-colors ${
                pathname === link.href ? "text-[#F5C065] underline" : ""
              }`}
            >
              {link.label}
            </Link>
          ))}

          {usuario ? (
            <button
              onClick={logout}
              className="text-sm font-light tracking-wide hover:text-[#F5C065] transition-colors"
            >
              LOGOUT
            </button>
          ) : (
            <Link
              href="/login"
              className={`text-sm font-light tracking-wide hover:text-[#F5C065] transition-colors ${
                pathname === "/login" ? "text-[#F5C065] underline" : ""
              }`}
            >
              LOGIN
            </Link>
          )}
        </nav>
      </div>
    </header>
  )
}
